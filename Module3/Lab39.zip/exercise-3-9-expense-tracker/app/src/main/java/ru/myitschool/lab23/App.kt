package ru.myitschool.lab23

import android.app.Application

class App: Application() {
    val financialOperationService = FinancialOperationService()
}