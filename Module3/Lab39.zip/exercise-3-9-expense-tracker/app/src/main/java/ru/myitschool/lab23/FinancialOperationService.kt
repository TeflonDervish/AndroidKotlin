package ru.myitschool.lab23

class FinancialOperationService {
    var operations = mutableListOf<FinancialOperation>()
    var balance: Float = 0f


}